package chooserDay;

public interface EventDateChooser {

    public void dateSelected(SelectedAction action, SelectedDate date);
}
